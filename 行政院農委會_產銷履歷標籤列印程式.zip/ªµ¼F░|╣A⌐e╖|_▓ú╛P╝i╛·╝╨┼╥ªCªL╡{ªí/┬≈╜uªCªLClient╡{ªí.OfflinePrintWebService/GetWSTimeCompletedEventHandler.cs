using System.CodeDom.Compiler;

namespace 離線列印Client程式.OfflinePrintWebService
{
	[GeneratedCode("System.Web.Services", "4.6.1087.0")]
	public delegate void GetWSTimeCompletedEventHandler(object sender, GetWSTimeCompletedEventArgs e);
}
