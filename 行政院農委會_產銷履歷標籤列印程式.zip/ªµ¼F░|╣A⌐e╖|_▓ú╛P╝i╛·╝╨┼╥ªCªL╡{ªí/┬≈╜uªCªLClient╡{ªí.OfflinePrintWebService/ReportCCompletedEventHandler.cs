using System.CodeDom.Compiler;
using System.ComponentModel;

namespace 離線列印Client程式.OfflinePrintWebService
{
	[GeneratedCode("System.Web.Services", "4.6.1087.0")]
	public delegate void ReportCCompletedEventHandler(object sender, AsyncCompletedEventArgs e);
}
