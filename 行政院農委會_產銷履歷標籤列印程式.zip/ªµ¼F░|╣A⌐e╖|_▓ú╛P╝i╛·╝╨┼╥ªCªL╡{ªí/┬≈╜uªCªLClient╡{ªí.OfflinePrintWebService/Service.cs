using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Threading;
using System.Web.Services;
using System.Web.Services.Description;
using System.Web.Services.Protocols;
using System.Xml.Serialization;
using 離線列印Client程式.Properties;

namespace 離線列印Client程式.OfflinePrintWebService
{
	[GeneratedCode("System.Web.Services", "4.6.1087.0")]
	[DebuggerStepThrough]
	[DesignerCategory("code")]
	[WebServiceBinding(Name = "ServiceSoap", Namespace = "http://tempuri.org/")]
	public class Service : SoapHttpClientProtocol
	{
		private SendOrPostCallback HelloWorldOperationCompleted;

		private SendOrPostCallback GetWSTimeOperationCompleted;

		private SendOrPostCallback GetOrgNameOperationCompleted;

		private SendOrPostCallback GetOrgIDOperationCompleted;

		private SendOrPostCallback UploadSNOperationCompleted;

		private SendOrPostCallback IsUploadDBOperationCompleted;

		private SendOrPostCallback UploadDBOperationCompleted;

		private SendOrPostCallback ReportVerNoOperationCompleted;

		private SendOrPostCallback UpdateSysSNOperationCompleted;

		private SendOrPostCallback ReportCOperationCompleted;

		private SendOrPostCallback L09OperationCompleted;

		private SendOrPostCallback L01OperationCompleted;

		private SendOrPostCallback GetPrintCodesOperationCompleted;

		private SendOrPostCallback DledPrintCodesOperationCompleted;

		private bool useDefaultCredentialsSetExplicitly;

		public new string Url
		{
			get
			{
				return base.Url;
			}
			set
			{
				if (IsLocalFileSystemWebService(base.Url) && !useDefaultCredentialsSetExplicitly && !IsLocalFileSystemWebService(value))
				{
					base.UseDefaultCredentials = false;
				}
				base.Url = value;
			}
		}

		public new bool UseDefaultCredentials
		{
			get
			{
				return base.UseDefaultCredentials;
			}
			set
			{
				base.UseDefaultCredentials = value;
				useDefaultCredentialsSetExplicitly = true;
			}
		}

		public event HelloWorldCompletedEventHandler HelloWorldCompleted;

		public event GetWSTimeCompletedEventHandler GetWSTimeCompleted;

		public event GetOrgNameCompletedEventHandler GetOrgNameCompleted;

		public event GetOrgIDCompletedEventHandler GetOrgIDCompleted;

		public event UploadSNCompletedEventHandler UploadSNCompleted;

		public event IsUploadDBCompletedEventHandler IsUploadDBCompleted;

		public event UploadDBCompletedEventHandler UploadDBCompleted;

		public event ReportVerNoCompletedEventHandler ReportVerNoCompleted;

		public event UpdateSysSNCompletedEventHandler UpdateSysSNCompleted;

		public event ReportCCompletedEventHandler ReportCCompleted;

		public event L09CompletedEventHandler L09Completed;

		public event L01CompletedEventHandler L01Completed;

		public event GetPrintCodesCompletedEventHandler GetPrintCodesCompleted;

		public event DledPrintCodesCompletedEventHandler DledPrintCodesCompleted;

		public Service()
		{
			Url = Settings.Default.離線列印Client程式_OfflinePrintWebService_Service;
			if (IsLocalFileSystemWebService(Url))
			{
				UseDefaultCredentials = true;
				useDefaultCredentialsSetExplicitly = false;
			}
			else
			{
				useDefaultCredentialsSetExplicitly = true;
			}
		}

		[SoapDocumentMethod("http://tempuri.org/HelloWorld", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string HelloWorld()
		{
			return (string)Invoke("HelloWorld", new object[0])[0];
		}

		public void HelloWorldAsync()
		{
			HelloWorldAsync(null);
		}

		public void HelloWorldAsync(object userState)
		{
			if (HelloWorldOperationCompleted == null)
			{
				HelloWorldOperationCompleted = new SendOrPostCallback(OnHelloWorldOperationCompleted);
			}
			InvokeAsync("HelloWorld", new object[0], HelloWorldOperationCompleted, userState);
		}

		private void OnHelloWorldOperationCompleted(object arg)
		{
			if (this.HelloWorldCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.HelloWorldCompleted(this, new HelloWorldCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/GetWSTime", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string GetWSTime()
		{
			return (string)Invoke("GetWSTime", new object[0])[0];
		}

		public void GetWSTimeAsync()
		{
			GetWSTimeAsync(null);
		}

		public void GetWSTimeAsync(object userState)
		{
			if (GetWSTimeOperationCompleted == null)
			{
				GetWSTimeOperationCompleted = new SendOrPostCallback(OnGetWSTimeOperationCompleted);
			}
			InvokeAsync("GetWSTime", new object[0], GetWSTimeOperationCompleted, userState);
		}

		private void OnGetWSTimeOperationCompleted(object arg)
		{
			if (this.GetWSTimeCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.GetWSTimeCompleted(this, new GetWSTimeCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/GetOrgName", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string GetOrgName(string authCode)
		{
			return (string)Invoke("GetOrgName", new object[1]
			{
				authCode
			})[0];
		}

		public void GetOrgNameAsync(string authCode)
		{
			GetOrgNameAsync(authCode, null);
		}

		public void GetOrgNameAsync(string authCode, object userState)
		{
			if (GetOrgNameOperationCompleted == null)
			{
				GetOrgNameOperationCompleted = new SendOrPostCallback(OnGetOrgNameOperationCompleted);
			}
			InvokeAsync("GetOrgName", new object[1]
			{
				authCode
			}, GetOrgNameOperationCompleted, userState);
		}

		private void OnGetOrgNameOperationCompleted(object arg)
		{
			if (this.GetOrgNameCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.GetOrgNameCompleted(this, new GetOrgNameCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/GetOrgID", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string GetOrgID(string authCode)
		{
			return (string)Invoke("GetOrgID", new object[1]
			{
				authCode
			})[0];
		}

		public void GetOrgIDAsync(string authCode)
		{
			GetOrgIDAsync(authCode, null);
		}

		public void GetOrgIDAsync(string authCode, object userState)
		{
			if (GetOrgIDOperationCompleted == null)
			{
				GetOrgIDOperationCompleted = new SendOrPostCallback(OnGetOrgIDOperationCompleted);
			}
			InvokeAsync("GetOrgID", new object[1]
			{
				authCode
			}, GetOrgIDOperationCompleted, userState);
		}

		private void OnGetOrgIDOperationCompleted(object arg)
		{
			if (this.GetOrgIDCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.GetOrgIDCompleted(this, new GetOrgIDCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/UploadSN", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string UploadSN(string authCode, string OrgID)
		{
			return (string)Invoke("UploadSN", new object[2]
			{
				authCode,
				OrgID
			})[0];
		}

		public void UploadSNAsync(string authCode, string OrgID)
		{
			UploadSNAsync(authCode, OrgID, null);
		}

		public void UploadSNAsync(string authCode, string OrgID, object userState)
		{
			if (UploadSNOperationCompleted == null)
			{
				UploadSNOperationCompleted = new SendOrPostCallback(OnUploadSNOperationCompleted);
			}
			InvokeAsync("UploadSN", new object[2]
			{
				authCode,
				OrgID
			}, UploadSNOperationCompleted, userState);
		}

		private void OnUploadSNOperationCompleted(object arg)
		{
			if (this.UploadSNCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.UploadSNCompleted(this, new UploadSNCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/IsUploadDB", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string IsUploadDB(string authCode)
		{
			return (string)Invoke("IsUploadDB", new object[1]
			{
				authCode
			})[0];
		}

		public void IsUploadDBAsync(string authCode)
		{
			IsUploadDBAsync(authCode, null);
		}

		public void IsUploadDBAsync(string authCode, object userState)
		{
			if (IsUploadDBOperationCompleted == null)
			{
				IsUploadDBOperationCompleted = new SendOrPostCallback(OnIsUploadDBOperationCompleted);
			}
			InvokeAsync("IsUploadDB", new object[1]
			{
				authCode
			}, IsUploadDBOperationCompleted, userState);
		}

		private void OnIsUploadDBOperationCompleted(object arg)
		{
			if (this.IsUploadDBCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.IsUploadDBCompleted(this, new IsUploadDBCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/UploadDB", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string UploadDB(string authCode, [XmlElement(DataType = "base64Binary")] byte[] fs)
		{
			return (string)Invoke("UploadDB", new object[2]
			{
				authCode,
				fs
			})[0];
		}

		public void UploadDBAsync(string authCode, byte[] fs)
		{
			UploadDBAsync(authCode, fs, null);
		}

		public void UploadDBAsync(string authCode, byte[] fs, object userState)
		{
			if (UploadDBOperationCompleted == null)
			{
				UploadDBOperationCompleted = new SendOrPostCallback(OnUploadDBOperationCompleted);
			}
			InvokeAsync("UploadDB", new object[2]
			{
				authCode,
				fs
			}, UploadDBOperationCompleted, userState);
		}

		private void OnUploadDBOperationCompleted(object arg)
		{
			if (this.UploadDBCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.UploadDBCompleted(this, new UploadDBCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/ReportVerNo", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string ReportVerNo(string authCode, string VerNo)
		{
			return (string)Invoke("ReportVerNo", new object[2]
			{
				authCode,
				VerNo
			})[0];
		}

		public void ReportVerNoAsync(string authCode, string VerNo)
		{
			ReportVerNoAsync(authCode, VerNo, null);
		}

		public void ReportVerNoAsync(string authCode, string VerNo, object userState)
		{
			if (ReportVerNoOperationCompleted == null)
			{
				ReportVerNoOperationCompleted = new SendOrPostCallback(OnReportVerNoOperationCompleted);
			}
			InvokeAsync("ReportVerNo", new object[2]
			{
				authCode,
				VerNo
			}, ReportVerNoOperationCompleted, userState);
		}

		private void OnReportVerNoOperationCompleted(object arg)
		{
			if (this.ReportVerNoCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.ReportVerNoCompleted(this, new ReportVerNoCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/UpdateSysSN", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string UpdateSysSN(string prevAuthCode, string currAuthCode)
		{
			return (string)Invoke("UpdateSysSN", new object[2]
			{
				prevAuthCode,
				currAuthCode
			})[0];
		}

		public void UpdateSysSNAsync(string prevAuthCode, string currAuthCode)
		{
			UpdateSysSNAsync(prevAuthCode, currAuthCode, null);
		}

		public void UpdateSysSNAsync(string prevAuthCode, string currAuthCode, object userState)
		{
			if (UpdateSysSNOperationCompleted == null)
			{
				UpdateSysSNOperationCompleted = new SendOrPostCallback(OnUpdateSysSNOperationCompleted);
			}
			InvokeAsync("UpdateSysSN", new object[2]
			{
				prevAuthCode,
				currAuthCode
			}, UpdateSysSNOperationCompleted, userState);
		}

		private void OnUpdateSysSNOperationCompleted(object arg)
		{
			if (this.UpdateSysSNCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.UpdateSysSNCompleted(this, new UpdateSysSNCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/ReportC", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public void ReportC(string authCode, string desc)
		{
			Invoke("ReportC", new object[2]
			{
				authCode,
				desc
			});
		}

		public void ReportCAsync(string authCode, string desc)
		{
			ReportCAsync(authCode, desc, null);
		}

		public void ReportCAsync(string authCode, string desc, object userState)
		{
			if (ReportCOperationCompleted == null)
			{
				ReportCOperationCompleted = new SendOrPostCallback(OnReportCOperationCompleted);
			}
			InvokeAsync("ReportC", new object[2]
			{
				authCode,
				desc
			}, ReportCOperationCompleted, userState);
		}

		private void OnReportCOperationCompleted(object arg)
		{
			if (this.ReportCCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.ReportCCompleted(this, new AsyncCompletedEventArgs(invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/L09", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string L09(string au, string fb)
		{
			return (string)Invoke("L09", new object[2]
			{
				au,
				fb
			})[0];
		}

		public void L09Async(string au, string fb)
		{
			L09Async(au, fb, null);
		}

		public void L09Async(string au, string fb, object userState)
		{
			if (L09OperationCompleted == null)
			{
				L09OperationCompleted = new SendOrPostCallback(OnL09OperationCompleted);
			}
			InvokeAsync("L09", new object[2]
			{
				au,
				fb
			}, L09OperationCompleted, userState);
		}

		private void OnL09OperationCompleted(object arg)
		{
			if (this.L09Completed != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.L09Completed(this, new L09CompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/L01", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public string L01(string au, string fb)
		{
			return (string)Invoke("L01", new object[2]
			{
				au,
				fb
			})[0];
		}

		public void L01Async(string au, string fb)
		{
			L01Async(au, fb, null);
		}

		public void L01Async(string au, string fb, object userState)
		{
			if (L01OperationCompleted == null)
			{
				L01OperationCompleted = new SendOrPostCallback(OnL01OperationCompleted);
			}
			InvokeAsync("L01", new object[2]
			{
				au,
				fb
			}, L01OperationCompleted, userState);
		}

		private void OnL01OperationCompleted(object arg)
		{
			if (this.L01Completed != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.L01Completed(this, new L01CompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/GetPrintCodes", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public DataSet GetPrintCodes(string authCode)
		{
			return (DataSet)Invoke("GetPrintCodes", new object[1]
			{
				authCode
			})[0];
		}

		public void GetPrintCodesAsync(string authCode)
		{
			GetPrintCodesAsync(authCode, null);
		}

		public void GetPrintCodesAsync(string authCode, object userState)
		{
			if (GetPrintCodesOperationCompleted == null)
			{
				GetPrintCodesOperationCompleted = new SendOrPostCallback(OnGetPrintCodesOperationCompleted);
			}
			InvokeAsync("GetPrintCodes", new object[1]
			{
				authCode
			}, GetPrintCodesOperationCompleted, userState);
		}

		private void OnGetPrintCodesOperationCompleted(object arg)
		{
			if (this.GetPrintCodesCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.GetPrintCodesCompleted(this, new GetPrintCodesCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		[SoapDocumentMethod("http://tempuri.org/DledPrintCodes", RequestNamespace = "http://tempuri.org/", ResponseNamespace = "http://tempuri.org/", Use = SoapBindingUse.Literal, ParameterStyle = SoapParameterStyle.Wrapped)]
		public bool DledPrintCodes(string authCode, int[] rID)
		{
			return (bool)Invoke("DledPrintCodes", new object[2]
			{
				authCode,
				rID
			})[0];
		}

		public void DledPrintCodesAsync(string authCode, int[] rID)
		{
			DledPrintCodesAsync(authCode, rID, null);
		}

		public void DledPrintCodesAsync(string authCode, int[] rID, object userState)
		{
			if (DledPrintCodesOperationCompleted == null)
			{
				DledPrintCodesOperationCompleted = new SendOrPostCallback(OnDledPrintCodesOperationCompleted);
			}
			InvokeAsync("DledPrintCodes", new object[2]
			{
				authCode,
				rID
			}, DledPrintCodesOperationCompleted, userState);
		}

		private void OnDledPrintCodesOperationCompleted(object arg)
		{
			if (this.DledPrintCodesCompleted != null)
			{
				InvokeCompletedEventArgs invokeCompletedEventArgs = (InvokeCompletedEventArgs)arg;
				this.DledPrintCodesCompleted(this, new DledPrintCodesCompletedEventArgs(invokeCompletedEventArgs.Results, invokeCompletedEventArgs.Error, invokeCompletedEventArgs.Cancelled, invokeCompletedEventArgs.UserState));
			}
		}

		public new void CancelAsync(object userState)
		{
			base.CancelAsync(userState);
		}

		private bool IsLocalFileSystemWebService(string url)
		{
			if (url == null || url == string.Empty)
			{
				return false;
			}
			Uri uri = new Uri(url);
			if (uri.Port >= 1024 && string.Compare(uri.Host, "localHost", StringComparison.OrdinalIgnoreCase) == 0)
			{
				return true;
			}
			return false;
		}
	}
}
