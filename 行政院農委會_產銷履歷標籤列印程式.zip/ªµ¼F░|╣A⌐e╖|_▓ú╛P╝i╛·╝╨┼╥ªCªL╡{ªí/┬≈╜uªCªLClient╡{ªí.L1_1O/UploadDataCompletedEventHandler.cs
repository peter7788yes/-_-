using System.CodeDom.Compiler;

namespace 離線列印Client程式.L1_1O
{
	[GeneratedCode("System.Web.Services", "4.6.1087.0")]
	public delegate void UploadDataCompletedEventHandler(object sender, UploadDataCompletedEventArgs e);
}
