using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace 離線列印Client程式.Properties
{
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default
		{
			get
			{
				return defaultInstance;
			}
		}

		[ApplicationScopedSetting]
		[DebuggerNonUserCode]
		[SpecialSetting(SpecialSetting.WebServiceUrl)]
		[DefaultSettingValue("http://taftadmin.hyweb.com.tw/OffLinePrintWS/Service.asmx")]
		public string 離線列印Client程式_OfflinePrintWebService_Service
		{
			get
			{
				return (string)this["離線列印Client程式_OfflinePrintWebService_Service"];
			}
		}

		[ApplicationScopedSetting]
		[DebuggerNonUserCode]
		[SpecialSetting(SpecialSetting.WebServiceUrl)]
		[DefaultSettingValue("http://taftadmin.hyweb.com.tw/L1_1O.asmx")]
		public string 離線列印Client程式_L1_1O_L1_1O
		{
			get
			{
				return (string)this["離線列印Client程式_L1_1O_L1_1O"];
			}
		}
	}
}
