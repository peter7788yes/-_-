namespace T00SharedLibraryDotNet20
{
	public enum CommandOperationType
	{
		ExecuteNonQuery,
		ExecuteReader,
		ExecuteScalar,
		ExecuteReaderReturnDataTable
	}
}
