namespace T00SharedLibraryDotNet20
{
	public enum TableOperation
	{
		Select,
		Insert,
		Delete,
		Update
	}
}
