using MW6QRCodeASPNet;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using 離線列印Client程式;

public class QRCode : PrintDocument
{
	private string _qr;

	private string _ProductName;

	private string _AuthName;

	private string _PackDate;

	private string _ExpDate;

	private string _eanCode;

	private string _fontName;

	private string _printCodeSrt;

	private string _ProducerName;

	private string _CommonName;

	private string _ExpDateDesc;

	private string _UserInputLine;

	private short _qty;

	private int _printCodeAmt;

	private int _currentPrintedAmt;

	private int _TOX;

	private int _TOY;

	private int _QOX;

	private int _QOY;

	private Bitmap _qrCodeBMP;

	private Ean13 _ean13 = new Ean13();

	private PrintFormat _thisFormat;

	private bool _TraceCodeWithSlash;

	private bool _SetLandscaped;

	private bool _IsLandscape;

	private bool _IsRotate;

	public string QR
	{
		get
		{
			return _qr;
		}
		set
		{
			_qr = value;
		}
	}

	public string CommonName
	{
		get
		{
			return _CommonName;
		}
		set
		{
			_CommonName = value;
		}
	}

	public string Title
	{
		get
		{
			return _ProductName;
		}
		set
		{
			_ProductName = value;
		}
	}

	public string AuthName
	{
		get
		{
			return _AuthName;
		}
		set
		{
			_AuthName = value;
		}
	}

	public string ProducerName
	{
		get
		{
			return _ProducerName;
		}
		set
		{
			_ProducerName = value;
		}
	}

	public string PackDate
	{
		get
		{
			return _PackDate;
		}
		set
		{
			_PackDate = value;
		}
	}

	public string ExpDate
	{
		get
		{
			return _ExpDate;
		}
		set
		{
			_ExpDate = value;
		}
	}

	public string EanCode
	{
		get
		{
			return _eanCode;
		}
		set
		{
			_eanCode = value;
		}
	}

	public short PrintQuantity
	{
		get
		{
			return _qty;
		}
		set
		{
			_qty = value;
		}
	}

	public string PrinterFont
	{
		get
		{
			return _fontName;
		}
		set
		{
			_fontName = value;
		}
	}

	public bool IsRotate
	{
		get
		{
			return _IsRotate;
		}
		set
		{
			_IsRotate = value;
		}
	}

	public QRCode()
	{
		_qr = string.Empty;
		_ProductName = string.Empty;
		_AuthName = string.Empty;
		_PackDate = string.Empty;
		_ExpDate = string.Empty;
		_eanCode = string.Empty;
		_ProducerName = string.Empty;
		_CommonName = string.Empty;
		_UserInputLine = string.Empty;
		_ExpDateDesc = "有效日期";
		_qty = 0;
		_TOX = 0;
		_TOY = 0;
		_QOX = 0;
		_QOY = 0;
		_fontName = "新細明體";
		_TraceCodeWithSlash = false;
		_SetLandscaped = false;
		_IsLandscape = false;
		_IsRotate = false;
		base.PrintController = new StandardPrintController();
	}

	public QRCode(string qr, string ProductName, string AuthName, string PackDate, string ExpDate, string PrintCodeSrt, int PrintCodeAmt, string eanCode, PrintFormat printedFormat, string printerName, short qty, string producerName, string commonName, string expDateDesc, string userInputLine, bool traceCodeWithSlash, int tOX, int tOY, int qOX, int qOY, bool isRotate)
	{
		_qr = qr;
		_ProductName = ProductName;
		_AuthName = AuthName;
		_PackDate = PackDate;
		_ExpDate = ExpDate;
		_eanCode = eanCode;
		_printCodeAmt = PrintCodeAmt;
		_printCodeSrt = PrintCodeSrt;
		_ProducerName = producerName;
		_ExpDateDesc = expDateDesc;
		_UserInputLine = userInputLine;
		_TraceCodeWithSlash = traceCodeWithSlash;
		_CommonName = commonName;
		_currentPrintedAmt = 0;
		_qty = qty;
		_TOX = tOX;
		_TOY = tOY;
		_QOX = qOX;
		_QOY = qOY;
		_thisFormat = printedFormat;
		_SetLandscaped = false;
		_IsLandscape = false;
		_IsRotate = isRotate;
		base.PrintController = new StandardPrintController();
		if (printerName != string.Empty)
		{
			base.PrinterSettings.PrinterName = printerName;
		}
	}

	protected override void OnBeginPrint(PrintEventArgs e)
	{
		base.OnBeginPrint(e);
		base.PrinterSettings.Copies = _qty;
		if (!_SetLandscaped)
		{
			_IsLandscape = !base.DefaultPageSettings.Landscape;
			_SetLandscaped = true;
		}
		base.DefaultPageSettings.Landscape = _IsLandscape;
		DrawQRCode();
		DrawEanCode();
		CustomizeTag();
	}

	protected override void OnPrintPage(PrintPageEventArgs e)
	{
		base.OnPrintPage(e);
		try
		{
			string text = PrintCodeUtilties.GetNextNPrintCode(_printCodeSrt, _currentPrintedAmt + 1);
			if (text.Length > 7)
			{
				int num = Convert.ToInt32(text.Substring(7, 1));
				text = ((num == 9) ? (text.Substring(0, 10) + "-" + text.Substring(10)) : ((5 > num || num > 8) ? (text.Substring(0, 11) + "-" + text.Substring(11)) : (text.Substring(0, 9) + "-" + text.Substring(9))));
			}
			if (_thisFormat == PrintFormat.標籤56X30)
			{
				_qrCodeBMP = Scale(_qrCodeBMP, 60, 60);
			}
			else if (_thisFormat == PrintFormat.標籤75X42 || _thisFormat == PrintFormat.標籤75X42無EAN || _thisFormat == PrintFormat.標籤6品項 || _thisFormat == PrintFormat.標籤8品項)
			{
				_qrCodeBMP = Scale(_qrCodeBMP, 80, 80);
			}
			else
			{
				_qrCodeBMP = Scale(_qrCodeBMP, 75, 75);
			}
			switch (_thisFormat)
			{
			case PrintFormat.標籤45X52:
				_QOX += 5;
				_TOX += 5;
				if (!_IsRotate)
				{
					e.Graphics.DrawImage(_qrCodeBMP, 105 - _QOY, 85 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -15), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 10f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -97 + _TOY);
					e.Graphics.DrawString(_AuthName + "驗證" + ((_PackDate != string.Empty) ? (" " + _PackDate + "包裝") : ""), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -81 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -69 + _TOY);
				}
				else
				{
					_TOX += -5;
					_QOY += 190;
					_TOY += 186;
					e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(-3 + _TOX, -154 + _TOY), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 10f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -97 + _TOY);
					e.Graphics.DrawString(_AuthName + "驗證" + ((_PackDate != string.Empty) ? (" " + _PackDate + "包裝") : ""), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -81 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -69 + _TOY);
				}
				break;
			case PrintFormat.標籤1品項:
				_QOX += 5;
				_TOX += 5;
				if (!_IsRotate)
				{
					RectangleF layoutRectangle = new RectangleF(5f, -100f, 170f, 22f);
					e.Graphics.DrawImage(_qrCodeBMP, 105 - _QOY, 85 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -15), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					e.Graphics.DrawString(_AuthName + "驗證" + ((_PackDate != string.Empty) ? (" " + _PackDate + "包裝") : ""), new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -75 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -66 + _TOY);
				}
				else
				{
					RectangleF layoutRectangle = new RectangleF(1f, 87f, 170f, 22f);
					_TOX += -5;
					_QOY += 190;
					_TOY += 186;
					e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(-3 + _TOX, -154 + _TOY), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					e.Graphics.DrawString(_AuthName + "驗證" + ((_PackDate != string.Empty) ? (" " + _PackDate + "包裝") : ""), new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -75 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -66 + _TOY);
				}
				break;
			case PrintFormat.標籤45X52顯示保存日期:
				if (!_IsRotate)
				{
					e.Graphics.DrawImage(_qrCodeBMP, 105 - _QOY, 85 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -15), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -100 + _TOY);
					e.Graphics.DrawString(_AuthName + "驗證 " + _UserInputLine, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -85 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -74 + _TOY);
					e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝 ") : "") + ((_ExpDate != string.Empty) ? (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc)) : string.Empty), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -63 + _TOY);
				}
				else
				{
					_TOX++;
					_QOY += 190;
					_TOY += 186;
					e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(-3 + _TOX, -154 + _TOY), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -100 + _TOY);
					e.Graphics.DrawString(_AuthName + "驗證 " + _UserInputLine, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -85 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -74 + _TOY);
					e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝 ") : "") + ((_ExpDate != string.Empty) ? (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc)) : string.Empty), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -63 + _TOY);
				}
				break;
			case PrintFormat.標籤2品項:
				if (!_IsRotate)
				{
					RectangleF layoutRectangle = new RectangleF(1f, -101f, 160f, 22f);
					e.Graphics.DrawImage(_qrCodeBMP, 105 - _QOY, 85 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -15), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					e.Graphics.DrawString(_AuthName + "驗證 " + _UserInputLine, new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -77 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -69 + _TOY);
					e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝 ") : "") + ((_ExpDate != string.Empty) ? (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc)) : string.Empty), new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -61 + _TOY);
				}
				else
				{
					RectangleF layoutRectangle = new RectangleF(1f, 86f, 160f, 22f);
					_TOX++;
					_QOY += 190;
					_TOY += 186;
					e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(-3 + _TOX, -154 + _TOY), 0f, 0f, 1f, 1f);
					e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					e.Graphics.DrawString(_AuthName + "驗證 " + _UserInputLine, new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -77 + _TOY);
					e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -69 + _TOY);
					e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝 ") : "") + ((_ExpDate != string.Empty) ? (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc)) : string.Empty), new Font(_fontName, 5f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -61 + _TOY);
				}
				break;
			case PrintFormat.標籤45X52無EAN:
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -110 + _TOY);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -90 + _TOY);
				e.Graphics.DrawString("驗證機構: " + _AuthName, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -72 + _TOY);
				if (_PackDate != "")
				{
					e.Graphics.DrawString("包裝日期: " + _PackDate, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -54 + _TOY);
				}
				if (_ExpDate != "")
				{
					e.Graphics.DrawString(_ExpDateDesc + ": " + _ExpDate, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -36 + _TOY + ((_PackDate == "") ? (-18) : 0));
				}
				break;
			case PrintFormat.標籤3品項:
			{
				RectangleF layoutRectangle = new RectangleF(1f, -110f, 170f, 45f);
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -62 + _TOY);
				e.Graphics.DrawString("驗證機構: " + _AuthName, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -52 + _TOY);
				if (_PackDate != "")
				{
					e.Graphics.DrawString("包裝日期: " + _PackDate, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -42 + _TOY);
				}
				if (_ExpDate != "")
				{
					e.Graphics.DrawString(_ExpDateDesc + ": " + _ExpDate, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -32 + _TOY + ((_PackDate == "") ? (-10) : 0));
				}
				break;
			}
			case PrintFormat.標籤56X30:
				_QOY += 6;
				_TOX += 5;
				e.Graphics.DrawImage(_qrCodeBMP, 38 - _QOY, 152 + _QOX);
				e.Graphics.RotateTransform(90f);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 8f, FontStyle.Bold), Brushes.Black, 85 + _TOX, -91 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 8.6f, FontStyle.Bold), Brushes.Black, 85 + _TOX, -78 + _TOY);
				}
				if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 8f, FontStyle.Bold), Brushes.Black, 85 + _TOX, -64 + _TOY);
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 8.6f, FontStyle.Bold), Brushes.Black, 85 + _TOX, -51 + _TOY);
				}
				e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 10 + _TOX, -24 + _TOY);
				e.Graphics.DrawString(_AuthName + " 驗證", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 125 + _TOX, -11 + _TOY);
				break;
			case PrintFormat.畜產標籤:
				_QOX += 6;
				e.Graphics.DrawImage(_qrCodeBMP, 67 - _QOY, 85 + _QOX);
				e.Graphics.RotateTransform(90f);
				_TOX += 5;
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -64 + _TOY);
				e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝  ") : "") + ((_ExpDate == string.Empty) ? "" : (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc))), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -47 + _TOY);
				e.Graphics.DrawString(_AuthName + "驗證", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -34 + _TOY);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -22 + _TOY);
				break;
			case PrintFormat.標籤5品項:
			{
				RectangleF layoutRectangle = new RectangleF(5f, -64f, 160f, 22f);
				_QOX += 6;
				e.Graphics.DrawImage(_qrCodeBMP, 67 - _QOY, 85 + _QOX);
				e.Graphics.RotateTransform(90f);
				_TOX += 5;
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				e.Graphics.DrawString(((_PackDate != string.Empty) ? (_PackDate + "包裝  ") : "") + ((_ExpDate == string.Empty) ? "" : (_ExpDate + ((_ExpDateDesc.Length > 2) ? _ExpDateDesc.Substring(0, 2) : _ExpDateDesc))), new Font(_fontName, 6f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -42 + _TOY);
				e.Graphics.DrawString(_AuthName + "驗證", new Font(_fontName, 6f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -32 + _TOY);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 6f, FontStyle.Regular), Brushes.Black, 1 + _TOX, -22 + _TOY);
				break;
			}
			case PrintFormat.標籤75X42:
			{
				string s9;
				string text4;
				if (!_IsRotate)
				{
					e.Graphics.DrawImage(_qrCodeBMP, 39 - _QOY, 175 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -12), 2.4f, 38.5f, 0.9f, 0.9f);
					s9 = ((_ProductName.Length > 5) ? _ProductName.Substring(0, 5) : _ProductName);
					text4 = ((_ProductName.Length > 5) ? _ProductName.Substring(5) : string.Empty);
					e.Graphics.DrawString(s9, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -128 + _TOY);
					if (text4 != string.Empty)
					{
						e.Graphics.DrawString(text4, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
					}
					if (_PackDate != string.Empty)
					{
						e.Graphics.DrawString("包裝日期", new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
						e.Graphics.DrawString(_PackDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -89 + _TOY);
					}
					if (_ExpDate != string.Empty)
					{
						e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -76 + _TOY + ((_PackDate == "") ? (-26) : 0));
						e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -63 + _TOY + ((_PackDate == "") ? (-26) : 0));
					}
					e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -50 + _TOY);
					e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -37 + _TOY);
					e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
					break;
				}
				_TOX += -5;
				_QOY += 200;
				_QOX += 80;
				_TOY += 150;
				e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
				_ean13.DrawEan13Barcode(e.Graphics, new Point(5 + _TOX, -128 + _TOY), 2.4f, 33f, 0.9f, 0.9f);
				s9 = ((_ProductName.Length > 5) ? _ProductName.Substring(0, 5) : _ProductName);
				text4 = ((_ProductName.Length > 5) ? _ProductName.Substring(5) : string.Empty);
				e.Graphics.DrawString(s9, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -128 + _TOY);
				if (text4 != string.Empty)
				{
					e.Graphics.DrawString(text4, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
				}
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -89 + _TOY);
				}
				if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -76 + _TOY + ((_PackDate == "") ? (-26) : 0));
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -63 + _TOY + ((_PackDate == "") ? (-26) : 0));
				}
				e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -50 + _TOY);
				e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -37 + _TOY);
				e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
				break;
			}
			case PrintFormat.標籤6品項:
			{
				RectangleF layoutRectangle;
				if (!_IsRotate)
				{
					layoutRectangle = new RectangleF(102f, -127f, 60f, 70f);
					e.Graphics.DrawImage(_qrCodeBMP, 39 - _QOY, 175 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -12), 2.4f, 38.5f, 0.9f, 0.9f);
					e.Graphics.DrawString(_ProductName, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					if (_PackDate != string.Empty)
					{
						e.Graphics.DrawString("包裝日期", new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -74 + _TOY);
						e.Graphics.DrawString(_PackDate, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -66 + _TOY);
					}
					if (_ExpDate != string.Empty)
					{
						e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -58 + _TOY + ((_PackDate == "") ? (-16) : 0));
						e.Graphics.DrawString(_ExpDate, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -50 + _TOY + ((_PackDate == "") ? (-16) : 0));
					}
					e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -42 + _TOY);
					e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -33 + _TOY);
					e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
					break;
				}
				layoutRectangle = new RectangleF(97f, 20f, 60f, 70f);
				_TOX += -5;
				_QOY += 200;
				_QOX += 80;
				_TOY += 150;
				e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
				_ean13.DrawEan13Barcode(e.Graphics, new Point(5 + _TOX, -128 + _TOY), 2.4f, 33f, 0.9f, 0.9f);
				e.Graphics.DrawString(_ProductName, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -76 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -68 + _TOY);
				}
				if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -60 + _TOY + ((_PackDate == "") ? (-16) : 0));
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -52 + _TOY + ((_PackDate == "") ? (-16) : 0));
				}
				e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -42 + _TOY);
				e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -33 + _TOY);
				e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
				break;
			}
			case PrintFormat.標籤45X52無EAN加自行輸入:
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -110 + _TOY);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -92 + _TOY);
				e.Graphics.DrawString("驗證機構: " + _AuthName, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -78 + _TOY);
				if (_PackDate != "")
				{
					e.Graphics.DrawString("包裝日期: " + _PackDate, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -64 + _TOY);
				}
				if (_ExpDate != "")
				{
					e.Graphics.DrawString(_ExpDateDesc + ": " + _ExpDate, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -50 + _TOY + ((_PackDate == "") ? (-14) : 0));
				}
				if (_UserInputLine != string.Empty)
				{
					e.Graphics.DrawString(_UserInputLine, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -36 + _TOY + ((_PackDate == "") ? (-14) : 0) + ((_ExpDate == "") ? (-14) : 0));
				}
				break;
			case PrintFormat.標籤7品項:
			{
				RectangleF layoutRectangle = new RectangleF(1f, -110f, 160f, 34f);
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -72 + _TOY);
				e.Graphics.DrawString("驗證機構: " + _AuthName, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -62 + _TOY);
				if (_PackDate != "")
				{
					e.Graphics.DrawString("包裝日期: " + _PackDate, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -52 + _TOY);
				}
				if (_ExpDate != "")
				{
					e.Graphics.DrawString(_ExpDateDesc + ": " + _ExpDate, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -42 + _TOY + ((_PackDate == "") ? (-10) : 0));
				}
				if (_UserInputLine != string.Empty)
				{
					e.Graphics.DrawString(_UserInputLine, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -32 + _TOY + ((_PackDate == "") ? (-10) : 0) + ((_ExpDate == "") ? (-10) : 0));
				}
				break;
			}
			case PrintFormat.標籤75X42無EAN:
			{
				e.Graphics.DrawImage(_qrCodeBMP, 30 - _QOY, 175 + _QOX);
				e.Graphics.RotateTransform(90f);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -112 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -99 + _TOY);
				}
				if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -86 + _TOY);
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -73 + _TOY);
				}
				e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -50 + _TOY);
				e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -37 + _TOY);
				e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
				string s9 = (_ProductName.Length > 8) ? _ProductName.Substring(0, 8) : _ProductName;
				string text4 = (_ProductName.Length > 8) ? _ProductName.Substring(8) : string.Empty;
				e.Graphics.DrawString(s9, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 175 + _TOX, -26 + _TOY);
				if (text4 != string.Empty)
				{
					e.Graphics.DrawString(text4, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 175 + _TOX, -12 + _TOY);
				}
				break;
			}
			case PrintFormat.標籤8品項:
			{
				RectangleF layoutRectangle = new RectangleF(175f, -48f, 110f, 47f);
				e.Graphics.DrawImage(_qrCodeBMP, 50 - _QOY, 175 + _QOX, 60, 60);
				e.Graphics.RotateTransform(90f);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -112 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -99 + _TOY);
				}
				if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -86 + _TOY);
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -73 + _TOY);
				}
				e.Graphics.DrawString("驗證機構 " + _AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -50 + _TOY);
				e.Graphics.DrawString("業者  \u3000 " + _ProducerName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -37 + _TOY);
				e.Graphics.DrawString("追溯號碼 " + text, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -24 + _TOY);
				e.Graphics.DrawString(_ProductName, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				break;
			}
			case PrintFormat.標籤45X52含生產者資訊:
			{
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 9f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -110 + _TOY);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -92 + _TOY);
				e.Graphics.DrawString(_AuthName + " 驗證 " + ((_PackDate != string.Empty) ? (_PackDate + "包裝") : ((_ExpDate != string.Empty) ? ("保存至" + _ExpDate) : "")), new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -78 + _TOY);
				string[] array = _UserInputLine.Split('＠');
				e.Graphics.DrawString(array[0], new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -64 + _TOY);
				string text3 = array[1];
				e.Graphics.DrawString((text3.Length > 13) ? text3.Substring(0, 13) : text3, new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -50 + _TOY);
				if (text3.Length > 13)
				{
					e.Graphics.DrawString(text3.Substring(13, text3.Length - 13), new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -36 + _TOY);
				}
				else
				{
					e.Graphics.DrawString(array[2], new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -36 + _TOY);
				}
				if (text3.Length > 13)
				{
					e.Graphics.DrawString(array[2], new Font(_fontName, 7.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -22 + _TOY);
				}
				break;
			}
			case PrintFormat.標籤9品項:
			{
				RectangleF layoutRectangle = new RectangleF(1f, -110f, 160f, 34f);
				e.Graphics.DrawImage(_qrCodeBMP, 112 - _QOY, 88 + _QOX);
				e.Graphics.RotateTransform(90f);
				e.Graphics.DrawString(_ProductName + ((_CommonName == string.Empty) ? string.Empty : ("(" + _CommonName + ")")), new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				e.Graphics.DrawString("追溯號碼: " + text, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -72 + _TOY);
				e.Graphics.DrawString(_AuthName + " 驗證 " + ((_PackDate != string.Empty) ? (_PackDate + "包裝") : ((_ExpDate != string.Empty) ? ("保存至" + _ExpDate) : "")), new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -62 + _TOY);
				string[] array2 = _UserInputLine.Split('＠');
				e.Graphics.DrawString(array2[0], new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -52 + _TOY);
				string text2 = array2[1];
				e.Graphics.DrawString((text2.Length > 13) ? text2.Substring(0, 13) : text2, new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -42 + _TOY);
				if (text2.Length > 13)
				{
					e.Graphics.DrawString(text2.Substring(13, text2.Length - 13), new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -32 + _TOY);
				}
				else
				{
					e.Graphics.DrawString(array2[2], new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -32 + _TOY);
				}
				if (text2.Length > 13)
				{
					e.Graphics.DrawString(array2[2], new Font(_fontName, 5.8f, FontStyle.Bold), Brushes.Black, 1 + _TOX, -22 + _TOY);
				}
				break;
			}
			case PrintFormat.標籤75X42含生產者資訊:
			{
				string[] array;
				if (!_IsRotate)
				{
					e.Graphics.DrawImage(_qrCodeBMP, 39 - _QOY, 175 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -12), 2.4f, 38.5f, 0.9f, 0.9f);
					e.Graphics.DrawString(_ProductName, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -132 + _TOY);
					if (_PackDate != string.Empty)
					{
						e.Graphics.DrawString("包裝日期", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
						e.Graphics.DrawString(_PackDate, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
					}
					else if (_ExpDate != string.Empty)
					{
						e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
						e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
					}
					e.Graphics.DrawString("驗證機構", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -89 + _TOY);
					e.Graphics.DrawString(_AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -76 + _TOY);
					array = _UserInputLine.Split('＠');
					e.Graphics.DrawString("追溯號碼：" + text, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -55 + _TOY);
					e.Graphics.DrawString(array[0], new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -45 + _TOY);
					e.Graphics.DrawString(array[2], new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -35 + _TOY);
					string s5 = (array[1].Length > 16) ? array[1].Substring(0, 16) : array[1];
					string s6 = (array[1].Length > 16) ? array[1].Substring(16) : string.Empty;
					e.Graphics.DrawString(s5, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -25 + _TOY);
					e.Graphics.DrawString(s6, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -15 + _TOY);
					break;
				}
				_TOX += -5;
				_QOY += 200;
				_QOX += 80;
				_TOY += 150;
				e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
				_ean13.DrawEan13Barcode(e.Graphics, new Point(5 + _TOX, -129 + _TOY), 2.4f, 33f, 0.9f, 0.9f);
				e.Graphics.DrawString(_ProductName, new Font(_fontName, 7.5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -132 + _TOY);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
				}
				else if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -115 + _TOY);
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -102 + _TOY);
				}
				e.Graphics.DrawString("驗證機構", new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -89 + _TOY);
				e.Graphics.DrawString(_AuthName, new Font(_fontName, 7f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -76 + _TOY);
				array = _UserInputLine.Split('＠');
				e.Graphics.DrawString("追溯號碼：" + text, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -55 + _TOY);
				e.Graphics.DrawString(array[0], new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -45 + _TOY);
				e.Graphics.DrawString(array[2], new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -35 + _TOY);
				string s7 = (array[1].Length > 16) ? array[1].Substring(0, 16) : array[1];
				string s8 = (array[1].Length > 16) ? array[1].Substring(16) : string.Empty;
				e.Graphics.DrawString(s7, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -25 + _TOY);
				e.Graphics.DrawString(s8, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -15 + _TOY);
				break;
			}
			case PrintFormat.標籤10品項:
			{
				RectangleF layoutRectangle;
				string[] array;
				if (!_IsRotate)
				{
					layoutRectangle = new RectangleF(102f, -127f, 60f, 70f);
					e.Graphics.DrawImage(_qrCodeBMP, 39 - _QOY, 175 + _QOX);
					e.Graphics.RotateTransform(90f);
					_ean13.DrawEan13Barcode(e.Graphics, new Point(0, -12), 2.4f, 38.5f, 0.9f, 0.9f);
					e.Graphics.DrawString(_ProductName, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, layoutRectangle);
					if (_PackDate != string.Empty)
					{
						e.Graphics.DrawString("包裝日期", new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -74 + _TOY);
						e.Graphics.DrawString(_PackDate, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -66 + _TOY);
					}
					else if (_ExpDate != string.Empty)
					{
						e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -74 + _TOY);
						e.Graphics.DrawString(_ExpDate, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -66 + _TOY);
					}
					e.Graphics.DrawString("驗證機構", new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -58 + _TOY);
					e.Graphics.DrawString(_AuthName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -50 + _TOY);
					array = _UserInputLine.Split('＠');
					e.Graphics.DrawString("追溯號碼：" + text, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -40 + _TOY);
					e.Graphics.DrawString(array[0], new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -30 + _TOY);
					e.Graphics.DrawString(array[2], new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -20 + _TOY);
					string s = (array[1].Length > 16) ? array[1].Substring(0, 16) : array[1];
					string s2 = (array[1].Length > 16) ? array[1].Substring(16) : string.Empty;
					e.Graphics.DrawString(s, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -10 + _TOY);
					e.Graphics.DrawString(s2, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, _TOY);
					break;
				}
				layoutRectangle = new RectangleF(97f, 20f, 60f, 70f);
				_TOX += -5;
				_QOY += 200;
				_QOX += 80;
				_TOY += 150;
				e.Graphics.DrawImage(_qrCodeBMP, 80 + _QOX, -188 + _QOY);
				_ean13.DrawEan13Barcode(e.Graphics, new Point(5 + _TOX, -129 + _TOY), 2.4f, 33f, 0.9f, 0.9f);
				e.Graphics.DrawString(_ProductName, new Font(_fontName, 5.5f, FontStyle.Bold), Brushes.Black, layoutRectangle);
				if (_PackDate != string.Empty)
				{
					e.Graphics.DrawString("包裝日期", new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -74 + _TOY);
					e.Graphics.DrawString(_PackDate, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -66 + _TOY);
				}
				else if (_ExpDate != string.Empty)
				{
					e.Graphics.DrawString(_ExpDateDesc, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -74 + _TOY);
					e.Graphics.DrawString(_ExpDate, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -66 + _TOY);
				}
				e.Graphics.DrawString("驗證機構", new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -58 + _TOY);
				e.Graphics.DrawString(_AuthName, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 102 + _TOX, -50 + _TOY);
				array = _UserInputLine.Split('＠');
				e.Graphics.DrawString("追溯號碼：" + text, new Font(_fontName, 6f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -40 + _TOY);
				e.Graphics.DrawString(array[0], new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -30 + _TOY);
				e.Graphics.DrawString(array[2], new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -20 + _TOY);
				string s3 = (array[1].Length > 16) ? array[1].Substring(0, 16) : array[1];
				string s4 = (array[1].Length > 16) ? array[1].Substring(16) : string.Empty;
				e.Graphics.DrawString(s3, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, -10 + _TOY);
				e.Graphics.DrawString(s4, new Font(_fontName, 5f, FontStyle.Bold), Brushes.Black, 4 + _TOX, _TOY);
				break;
			}
			}
			_currentPrintedAmt++;
			if (_printCodeAmt > _currentPrintedAmt)
			{
				e.HasMorePages = true;
			}
			else
			{
				e.HasMorePages = false;
			}
		}
		catch
		{
			e.HasMorePages = false;
		}
	}

	private void DrawQRCode()
	{
		try
		{
			int ActualRows = 0;
			int ActualCols = 0;
			int ActualWidth = 0;
			int ActualHeight = 0;
			Point p = new Point(0, 0);
			MW6QRCodeASPNet.QRCode qRCode = new MW6QRCodeASPNet.QRCode();
			qRCode.BackColor = Color.FromName("White");
			qRCode.BarColor = Color.FromName("Black");
			qRCode.Data = _qr;
			qRCode.Level = enumLevel.lvL;
			qRCode.Mask = enumMask.mkAuto;
			qRCode.Orientation = enumOrientation.or0;
			qRCode.Version = enumVersion.vrAuto;
			qRCode.ModuleSize = 0.07f;
			switch (_thisFormat)
			{
			case PrintFormat.標籤56X30:
				qRCode.ModuleSize = 0.06f;
				break;
			case PrintFormat.標籤75X42:
			case PrintFormat.標籤75X42無EAN:
			case PrintFormat.標籤6品項:
			case PrintFormat.標籤8品項:
				qRCode.ModuleSize = 0.1f;
				break;
			default:
				qRCode.ModuleSize = 0.07f;
				break;
			}
			qRCode.GetActualRC(ref ActualRows, ref ActualCols);
			qRCode.GetActualSize(ref ActualWidth, ref ActualHeight);
			qRCode.SetSize(ActualWidth, ActualHeight);
			Bitmap bitmap = new Bitmap(ActualWidth, ActualHeight);
			Graphics graphics = Graphics.FromImage(bitmap);
			qRCode.Render(graphics, p);
			graphics.Flush();
			_qrCodeBMP = bitmap;
		}
		catch
		{
		}
	}

	private void DrawEanCode()
	{
		try
		{
			if (_eanCode != string.Empty)
			{
				float[] printEanCodeParam = GetPrintEanCodeParam(_thisFormat);
				_ean13.CountryCode = _eanCode.Substring(0, 3);
				_ean13.ManufacturerCode = _eanCode.Substring(3, 4);
				_ean13.ProductCode = _eanCode.Substring(7, 5);
				_ean13.ChecksumDigit = _eanCode.Substring(12, 1);
				_ean13.Width = printEanCodeParam[0];
				_ean13.Height = printEanCodeParam[1];
				_ean13.FontSize = printEanCodeParam[2];
				_ean13.Scale = printEanCodeParam[3];
				_ean13.MarginLeft = printEanCodeParam[4];
				_ean13.MarginTop = printEanCodeParam[5];
				_ean13.MarginBarCode = printEanCodeParam[6];
			}
		}
		catch
		{
		}
	}

	private void CustomizeTag()
	{
		try
		{
			PrintFormat thisFormat = _thisFormat;
			if (thisFormat == PrintFormat.標籤56X30)
			{
				if (_PackDate.Length > 2)
				{
					_PackDate = Convert.ToDateTime(_PackDate).ToString("yyyyMMdd");
				}
				else
				{
					_PackDate = string.Empty;
				}
				if (_ExpDate.Length > 2)
				{
					_ExpDate = Convert.ToDateTime(_ExpDate).ToString("yyyyMMdd");
				}
				else
				{
					_ExpDate = string.Empty;
				}
			}
		}
		catch
		{
			PrintFormat thisFormat = _thisFormat;
			if (thisFormat == PrintFormat.標籤56X30)
			{
				_PackDate = string.Empty;
				_ExpDate = string.Empty;
			}
		}
	}

	private float[] GetPrintEanCodeParam(PrintFormat theFormat)
	{
		switch (theFormat)
		{
		case PrintFormat.標籤45X52:
		case PrintFormat.標籤1品項:
			return new float[7]
			{
				42.29f,
				14.23f,
				10f,
				0.8f,
				4f,
				0.7f,
				-0.4f
			};
		case PrintFormat.標籤45X52顯示保存日期:
		case PrintFormat.標籤2品項:
			return new float[7]
			{
				42.29f,
				12.23f,
				10f,
				0.8f,
				4f,
				2.3f,
				-0.4f
			};
		default:
			return new float[7]
			{
				42.29f,
				14.23f,
				10f,
				0.8f,
				4f,
				0.7f,
				-0.4f
			};
		}
	}

	private static Bitmap Scale(Bitmap image, int width, int height)
	{
		Bitmap bitmap = new Bitmap(width, height);
		bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
		using (Graphics graphics = Graphics.FromImage(bitmap))
		{
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.InterpolationMode = InterpolationMode.NearestNeighbor;
			graphics.PixelOffsetMode = PixelOffsetMode.Half;
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			graphics.DrawImage(image, 0, 0, bitmap.Width, bitmap.Height);
			return bitmap;
		}
	}

	private Bitmap ScaleByPercent(Bitmap imgPhoto, int Percent)
	{
		float num = (float)Percent / 100f;
		int width = imgPhoto.Width;
		int height = imgPhoto.Height;
		int x = 0;
		int y = 0;
		int x2 = 0;
		int y2 = 0;
		int width2 = (int)((float)width * num);
		int height2 = (int)((float)height * num);
		Bitmap bitmap = new Bitmap(width2, height2, PixelFormat.Format24bppRgb);
		bitmap.SetResolution(imgPhoto.HorizontalResolution, imgPhoto.VerticalResolution);
		Graphics graphics = Graphics.FromImage(bitmap);
		graphics.InterpolationMode = InterpolationMode.Low;
		graphics.DrawImage(imgPhoto, new Rectangle(x2, y2, width2, height2), new Rectangle(x, y, width, height), GraphicsUnit.Pixel);
		graphics.Dispose();
		return bitmap;
	}
}
