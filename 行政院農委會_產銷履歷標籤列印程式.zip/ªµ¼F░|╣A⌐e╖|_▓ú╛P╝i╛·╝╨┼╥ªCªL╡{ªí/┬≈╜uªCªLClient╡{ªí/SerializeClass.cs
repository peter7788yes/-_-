using Newtonsoft.Json;

namespace 離線列印Client程式
{
	public class SerializeClass
	{
		public string Serialize(bool ident)
		{
			try
			{
				return JsonConvert.SerializeObject(this, ident ? Formatting.Indented : Formatting.None);
			}
			catch
			{
				return string.Empty;
			}
		}
	}
}
