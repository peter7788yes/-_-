namespace 離線列印Client程式
{
	public enum UploadSySNType
	{
		未上傳序號,
		已上傳序號,
		序號改變未上傳,
		序號改變已上傳
	}
}
